package com.rws.Dojos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojosApplicationTests {

	@Test
	void contextLoads() {
	}

}
